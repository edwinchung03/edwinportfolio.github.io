﻿using COMP2139_Labs.Areas.ProjectManagement.Models;
using COMP2139_Labs.Data;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace COMP2139_Labs.Areas.ProjectManagement.Controllers
{
    public class TaskController : Controller
    {

        private readonly ApplicationDbContext _context;

        public TaskController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("Index")]
        public IActionResult Index(int projectId)
        {
            var tasks = _context.Tasks
                        .Where(t => t.ProjectID == projectId)
                        .ToList();
            ViewBag.ProjectId = projectId;

            return View(tasks);
        }
        [HttpGet("Details")]
        public IActionResult Details(int id)
        {
            var task = _context.Tasks
                .Include(t => t.Project)
                .FirstOrDefault(task => task.ProjectID == id);

            if (task == null)
            {
                return NotFound();
            }

            return View(task);
        }
        [HttpGet("Create")]
        public IActionResult Create(int projectId)
        {
            var project = _context.Projects.Find(projectId);

            if (project == null)
            {
                return NotFound();
            }

            var task = new ProjectTask
            {
                ProjectID = projectId
            };

            return View(task);
        }

        [HttpPost("Create")]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Title", "Description", "ProjectID")] ProjectTask task)
        {
            if (ModelState.IsValid)
            {
                _context.Tasks.Add(task);
                _context.SaveChanges();
                return RedirectToAction("Index", new { task.ProjectID });
            }

            ViewBag.Projects = new SelectList(_context.Projects, "ProjectID", "Name", task.ProjectID);

            return View(task);
        }

        [HttpGet("Edit")]
        public IActionResult Edit(int id)
        {
            var task = _context.Tasks
                .Include(t => t.Project)
                .FirstOrDefault(t => t.ProjectTaskId == id);

            if (task == null)
            {
                return NotFound();
            }

            ViewBag.Projects = new SelectList(_context.Projects, "ProjectID", "Name", task.ProjectID);
            return View(task);
        }

        [HttpPost("Edit")]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("ProjectTaskId", "Title", "Description", "ProjectID")] ProjectTask task)
        {
            if (id != task.ProjectTaskId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                _context.Tasks.Update(task);
                _context.SaveChanges();
                return RedirectToAction("Index", new { task.ProjectID });
            }

            ViewBag.Projects = new SelectList(_context.Projects, "ProjectID", "Name", task.ProjectID);
            return View(task);
        }

        [HttpGet("Delete")]
        public IActionResult Delete(int id)
        {
            var task = _context.Tasks
                .Include(t => t.Project)
                .FirstOrDefault(t => t.ProjectTaskId == id);

            if (task == null)
            {
                return NotFound();
            }

            ViewBag.Projects = new SelectList(_context.Projects, "ProjectID", "Name", task.ProjectID);
            return View(task);
        }

        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int projectTaskId)
        {
            var task = _context.Tasks.Find(projectTaskId);

            if (task != null)
            {
                _context.Tasks.Remove(task);
                _context.SaveChanges();
                return RedirectToAction("Index", new { task.ProjectID });
            }

            return NotFound();
        }

        public async Task<IActionResult> Search(int? projectId, string searchString)
        {
            var taskQuery = _context.Tasks.AsQueryable();

            if (projectId.HasValue)
            {
                taskQuery = taskQuery.Where(t => t.ProjectID == projectId.Value);
            }

            if (!string.IsNullOrEmpty(searchString))
            {
                taskQuery = taskQuery.Where(t => t.Title.Contains(searchString)
                                            || t.Description.Contains(searchString));
            }

            var tasks = await taskQuery.ToListAsync();
            ViewBag.ProjectID = projectId;
            return View("Index", tasks);
        }
    }
}
