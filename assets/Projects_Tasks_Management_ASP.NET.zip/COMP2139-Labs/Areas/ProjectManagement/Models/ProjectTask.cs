﻿using System.ComponentModel.DataAnnotations;

namespace COMP2139_Labs.Areas.ProjectManagement.Models
{
    public class ProjectTask
    {
        [Key]
        public int ProjectTaskId { get; set; }
        [Required]
        public string? Title { get; set; }
        [Required]
        public string? Description { get; set; }

        // foreign key for Project
        public int ProjectID { get; set; }

        // Navigation Property
        // Allows for easy access to the related project entity from the task 
        public Project? Project { get; set; }

    }
}
