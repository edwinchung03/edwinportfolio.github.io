﻿using System.ComponentModel.DataAnnotations;

namespace COMP2139_Labs.Areas.ProjectManagement.Models
{
    public class Project
    {
        [Key]
        public int ProjectID { get; set; }
        [Required]
        public required string Name { get; set; }
        public string? Description { get; set; }
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }
        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }
        public string? Status { get; set; }
        public List<ProjectTask>? Tasks { get; set; }





    }
}
